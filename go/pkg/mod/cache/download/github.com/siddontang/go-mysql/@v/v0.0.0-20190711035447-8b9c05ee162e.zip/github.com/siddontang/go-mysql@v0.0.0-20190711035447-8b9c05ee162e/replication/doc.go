/*
Replication package is to handle MySQL replication protocol.

Todo:

+ Get table information when handing rows event.
*/
package replication
