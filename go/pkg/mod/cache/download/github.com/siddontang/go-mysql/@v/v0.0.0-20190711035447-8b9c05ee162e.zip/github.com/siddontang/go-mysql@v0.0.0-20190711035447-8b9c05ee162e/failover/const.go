package failover

const (
	IOThreadType  = "IO_THREAD"
	SQLThreadType = "SQL_THREAD"
)

const (
	GTIDModeOn  = "ON"
	GTIDModeOff = "OFF"
)
