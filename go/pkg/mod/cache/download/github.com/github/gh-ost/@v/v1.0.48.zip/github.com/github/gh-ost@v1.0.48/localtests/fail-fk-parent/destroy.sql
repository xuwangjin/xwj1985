drop table if exists gh_ost_test_child;
