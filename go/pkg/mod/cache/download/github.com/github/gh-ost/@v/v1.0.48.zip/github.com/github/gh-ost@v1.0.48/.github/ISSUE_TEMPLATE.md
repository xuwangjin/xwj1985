> This is the place to report a bug, ask a question, or suggest an enhancement.

> This is also the place to make a discussion before creating a PR.

> If this is a bug report, please provide a test case (e.g., your table definition and gh-ost command) and the error output.

> Please use markdown to format code or SQL: https://guides.github.com/features/mastering-markdown/

> Please label the issue on the right (bug, enhancement, question, etc.).

> And please understand if this issue is not addressed immediately or in a timeframe you were expecting.

> Thank you!
