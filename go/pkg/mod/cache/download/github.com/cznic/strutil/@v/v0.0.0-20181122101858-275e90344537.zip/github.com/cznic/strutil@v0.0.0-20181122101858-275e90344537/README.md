`github.com/cznic/strutil` has moved to [`modernc.org/strutil`](https://godoc.org/modernc.org/strutil) ([vcs](https://gitlab.com/cznic/strutil)).

Please update your import paths to `modernc.org/strutil`.

This repo is now archived.
