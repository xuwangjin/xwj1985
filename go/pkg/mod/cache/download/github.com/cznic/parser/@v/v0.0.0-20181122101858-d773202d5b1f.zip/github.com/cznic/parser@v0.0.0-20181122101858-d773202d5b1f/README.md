`github.com/cznic/parser` has moved to [`modernc.org/parser`](https://godoc.org/modernc.org/parser) ([vcs](https://gitlab.com/cznic/parser)).

Please update your import paths to `modernc.org/parser`.

This repo is now archived.
