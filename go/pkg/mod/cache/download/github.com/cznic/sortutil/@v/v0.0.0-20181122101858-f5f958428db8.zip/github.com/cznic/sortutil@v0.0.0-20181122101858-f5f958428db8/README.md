`github.com/cznic/sortutil` has moved to [`modernc.org/sortutil`](https://godoc.org/modernc.org/sortutil) ([vcs](https://gitlab.com/cznic/sortutil)).

Please update your import paths to `modernc.org/sortutil`.

This repo is now archived.
