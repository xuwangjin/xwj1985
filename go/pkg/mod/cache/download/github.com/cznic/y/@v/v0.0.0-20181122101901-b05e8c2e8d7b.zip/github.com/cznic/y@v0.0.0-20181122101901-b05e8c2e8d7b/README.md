`github.com/cznic/y` has moved to [`modernc.org/y`](https://godoc.org/modernc.org/y) ([vcs](https://gitlab.com/cznic/y)).

Please update your import paths to `modernc.org/y`.

This repo is now archived.
