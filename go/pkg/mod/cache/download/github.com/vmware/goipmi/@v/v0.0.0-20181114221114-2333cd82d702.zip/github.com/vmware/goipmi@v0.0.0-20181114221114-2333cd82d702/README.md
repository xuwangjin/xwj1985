# goipmi [![CircleCI](https://circleci.com/gh/vmware/goipmi.svg?style=svg)](https://circleci.com/gh/vmware/goipmi)

Native IPMI implementation and `ipmitool` wrapper in Go.

## License

This project is available under the [Apache 2.0](./LICENSE) license.
