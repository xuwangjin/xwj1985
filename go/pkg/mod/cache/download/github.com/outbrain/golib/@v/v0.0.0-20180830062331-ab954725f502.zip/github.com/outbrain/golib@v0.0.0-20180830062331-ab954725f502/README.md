Outbrain's common go lang libraries

```
go get "github.com/outbrain/golib/math"
```